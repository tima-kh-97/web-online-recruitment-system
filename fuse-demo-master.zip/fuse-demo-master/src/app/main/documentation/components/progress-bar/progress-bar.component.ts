import { Component } from '@angular/core';

@Component({
    selector   : 'docs-components-progress-bar',
    templateUrl: './progress-bar.component.html',
    styleUrls  : ['./progress-bar.component.scss']
})
export class DocsComponentsProgressBarComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
